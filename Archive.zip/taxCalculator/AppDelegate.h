//
//  AppDelegate.h
//  taxCalculator
//
//  Created by Tommy Gibbons on 3/5/15.
//  Copyright (c) 2015 Tommy Gibbons. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

